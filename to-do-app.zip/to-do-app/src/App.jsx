import { Button, TextField } from "@mui/material"
import "./style.css"
import { useState } from "react"
function App() {
  const [textTarefa,setTextTarefa] = useState("");
  function mostrarvalor() {
    console.log(textTarefa)
  }


  return (
    <form className="form-container">
      <TextField value={textTarefa} id="standard-basic" label="Tarefa"
      variant="standard" placeholder="Digite a tarefa"
      onChange={({target}) => setTextTarefa(target.value)}/>
      <Button onClick={mostrarvalor} variant="contained" >Add</Button>
    </form>
  )
}

export default App
